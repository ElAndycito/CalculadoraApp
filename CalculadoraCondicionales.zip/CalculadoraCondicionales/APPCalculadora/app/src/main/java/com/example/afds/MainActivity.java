package com.example.afds;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView TvResultado;
    EditText EtNum1, EtNum2;
    Button BtSumar, BtRestar, BtMulti, BtDividir;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    TvResultado = findViewById(R.id.tv_resultado);
    EtNum1 = findViewById(R.id.et_num1);
    EtNum2 = findViewById(R.id.et_num2);
    BtSumar = findViewById(R.id.btn_sumar);
    BtRestar = findViewById(R.id.btn_restar);
    BtMulti = findViewById(R.id.btn_multiplicar);
    BtDividir = findViewById(R.id.btn_dividir);

    }
    public void Clicksumar(View view){
        if (EtNum1.getText().toString().equals("") || EtNum2.getText().toString().equals("")){
            Toast.makeText(this, "Hay campos vacios", Toast.LENGTH_SHORT).show();
        }
        else {
            String textNum1 = EtNum1.getText().toString();
            String textNum2 = EtNum2.getText().toString();
            Double num1 = Double.parseDouble(textNum1);
            Double num2 = Double.parseDouble(textNum2);
            Double resultado = num1+num2;
            TvResultado.setText(resultado.toString());
            EtNum1.setText("");
            EtNum2.setText("");
        }
    }
    public void Clickrestar(View view){
        if (EtNum1.getText().toString().equals("") || EtNum2.getText().toString().equals("")){
            Toast.makeText(this, "Hay campos vacios", Toast.LENGTH_SHORT).show();
        }
        else {
            String textNum1 = EtNum1.getText().toString();
            String textNum2 = EtNum2.getText().toString();
            Double num1 = Double.parseDouble(textNum1);
            Double num2 = Double.parseDouble(textNum2);
            Double resultado = num1-num2;
            TvResultado.setText(resultado.toString());
            EtNum1.setText("");
            EtNum2.setText("");
        }
    }
    public void Clickmultiplicar(View view){
        if (EtNum1.getText().toString().equals("") || EtNum2.getText().toString().equals("")){
            Toast.makeText(this, "Hay campos vacios", Toast.LENGTH_SHORT).show();
        }
        else {
            String textNum1 = EtNum1.getText().toString();
            String textNum2 = EtNum2.getText().toString();
            Double num1 = Double.parseDouble(textNum1);
            Double num2 = Double.parseDouble(textNum2);
            Double resultado = num1*num2;
            TvResultado.setText(resultado.toString());
            EtNum1.setText("");
            EtNum2.setText("");
        }
    }
    public void Clickdividir(View view){
        int cond=0;
        if (EtNum1.getText().toString().equals("") || EtNum2.getText().toString().equals("")){
            Toast.makeText(this, "Hay campos vacios", Toast.LENGTH_SHORT).show();
            cond=1;
        }
        if (EtNum2.getText().toString().equals("")){
            Toast.makeText(this, "Division por cero", Toast.LENGTH_SHORT).show();
            cond=1;
        }
        if (cond==0) {
            String textNum1 = EtNum1.getText().toString();
            String textNum2 = EtNum2.getText().toString();
            Double num1 = Double.parseDouble(textNum1);
            Double num2 = Double.parseDouble(textNum2);
            Double resultado = num1 / num2;
            TvResultado.setText(resultado.toString());
            EtNum1.setText("");
            EtNum2.setText("");
        }
        cond=0;
    }
}


