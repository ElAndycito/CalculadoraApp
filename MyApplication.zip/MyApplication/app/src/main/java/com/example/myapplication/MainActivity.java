package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_principal);
    }
    public void clickConstrain(View view){
        setContentView(R.layout.constrain_layout);
    }
    public void Clickmenu(View view){
        setContentView(R.layout.menu_principal);
    }
}