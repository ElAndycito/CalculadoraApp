package com.example.ciclovidaapp;

import static android.util.Log.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onCreate", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "in onCreate De Andrés");

    }
    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onStart", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "in onStart De Andrés");

    }
    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onResume", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "in onResume De Andrés");

    }
    @Override
    protected void onPause() {
        super.onPause();
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onPause", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "in onPause De Andrés");

    }
    @Override
    protected void onStop() {
        super.onStop();
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onStop", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "in onStop De Andrés");

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onDestroy", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "in onDestroy De Andrés");

    }
}
